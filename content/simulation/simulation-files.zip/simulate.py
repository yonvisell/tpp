#!/usr/bin/env python3
"""Reproduce three illustrative Rev08 control examples; no hardware data are fitted."""
from pathlib import Path
import csv, json, math
from dataclasses import dataclass, asdict
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

ROOT = Path(__file__).resolve().parent
CONTROLLER_SHA256 = 'bf0f14e31c0a9a35f22d2b3d7c503cd8a78cdaa7bfdbe2ac3a2096138fc7dae8'
A = 20.0
# AWS180 Rev.1: manufacturer table, not this laboratory's measured foil curve.
Q_T = np.array([20,100,200,300,400,500,600,700,800,900,1000,1100,1200.])
Q_R = np.array([1,1.006,1.015,1.028,1.045,1.065,1.068,1.057,1.051,1.052,1.062,1.071,1.080])
# Representative Nikrothal 80 heat-capacity data; separate material specification.
CP_T = np.array([20,100,200,300,400,500,600,700,800,900,1000,1100.])
CP = 1000*np.array([.46,.46,.48,.50,.52,.54,.56,.60,.63,.65,.67,.70])
MASS = 8300*0.010*0.001*0.000015  # kg; assumed 10 x 1 x 0.015 mm active strip.
R0 = 1.08e-6*.010/(.001*.000015)  # ohm; nominal rectangular-strip resistance.
V_ON, V_MAX = 2.7, 2.72
P_MAX = V_MAX**2/R0
P_OFF = 2e-6
C_MIN = MASS*CP[0]
GRID = np.arange(20.,801.,1.)
Q_GRID = np.interp(GRID,Q_T,Q_R)
L = float(np.max(np.abs(np.diff(Q_R)/np.diff(Q_T))))
SAMPLE_DT, TRUE_DT = .0002, .00001
SETTLE, OFF_DELAY, DATA_AGE = .0001, .00005, .001
E_R, MARGIN = .003, 15.0
V_BIAS, I_BIAS, NOISE_SD = .0003, -.0002, .0005
G, BETA, GAMMA = .010, 4.0, 1.0
EPS = 1e-11


def q(T): return float(np.interp(T,Q_T,Q_R))
def capacity(T): return MASS*float(np.interp(T,CP_T,CP))

@dataclass
class Case:
    key: str
    title: str
    mass_scale: float = 1.0
    G_scale: float = 1.0
    beta_scale: float = 1.0
    gamma_scale: float = 1.0
    width: float = 30.0
    ceiling: float = 450.0
    ambiguity: bool = False

@dataclass
class Pulse:
    number: int
    start: float
    requested: float
    command_off: float = math.inf
    physical_off: float = math.inf
    reason: str = ''
    energy: float = 0.0
    peak_T: float = A
    start_T: float = A
    start_S: float = A
    stop_estimate: float = A

class Simulation:
    def __init__(self,case):
        self.case=case; self.time=0.; self.truth=np.array([A,A]); self.estimate=np.array([A,A])
        self.state_time=0.; self.last_valid=0.; self.last_measurement=None
        self.command_on=False; self.actual_on=False; self.deadline=math.inf
        self.deadline_reason=''; self.pending_off=math.inf; self.active=None
        self.fault=''; self.ambiguity_snapshot=None; self.rows=[]
        self.rng=np.random.default_rng(20261023)
        if case.ambiguity: self.pulses=[Pulse(1,.05,.100)]
        else: self.pulses=[Pulse(i+1,.05+i*.15,d) for i,d in enumerate([.025,.050,.025,.050])]
        self.next_pulse=0; self.restart_added=case.ambiguity
        self.end_time=.30 if case.ambiguity else 1.15
        self.next_sample=SAMPLE_DT
        self.last_pred_T=A
        self.initial_row()

    def initial_row(self): self.record(None,'initial')
    def physical_power(self,T,on=None):
        return V_ON**2/(R0*q(T)) if (self.actual_on if on is None else on) else P_OFF
    def rhs(self,state):
        T,S=state; c=self.case
        power=self.physical_power(T)
        return np.array([(power-G*c.G_scale*(T-S))/(capacity(T)*c.mass_scale),
                         BETA*c.beta_scale*(T-S)-GAMMA*c.gamma_scale*(S-A)])
    def advance_truth(self,to):
        n=max(1,int(math.ceil((to-self.time)/TRUE_DT)))
        h=(to-self.time)/n
        for _ in range(n):
            old=self.truth.copy(); p0=self.physical_power(old[0])
            k1=self.rhs(old); k2=self.rhs(old+h*k1/2)
            k3=self.rhs(old+h*k2/2); k4=self.rhs(old+h*k3)
            self.truth=old+h*(k1+2*k2+2*k3+k4)/6
            if self.actual_on:
                self.active.energy+=h*(p0+self.physical_power(self.truth[0]))/2
                self.active.peak_T=max(self.active.peak_T,float(self.truth[0]))
        self.time=to

    def reading(self):
        if not(self.command_on and self.actual_on and self.time>=self.active.start+SETTLE-EPS): return None
        V=V_ON*(1+V_BIAS+self.rng.normal(0,NOISE_SD))
        I=V_ON/(R0*q(self.truth[0]))*(1+I_BIAS+self.rng.normal(0,NOISE_SD))
        return {'time':self.time,'V':V,'I':I,'P':V*I,'y':V/(I*R0),'pulse':self.active.number}

    def model_segments(self,begin,end,reading):
        boundaries=[begin,end]
        for p in self.pulses:
            for t in (p.start,p.start+SETTLE,p.command_off,p.physical_off):
                if begin+EPS<t<end-EPS: boundaries.append(t)
        boundaries=sorted(set(boundaries))
        pieces=[]
        for left,right in zip(boundaries[:-1],boundaries[1:]):
            middle=(left+right)/2
            p=next((p for p in self.pulses if p.start<=middle<p.physical_off and p.start<=self.time and p.number<=self.next_pulse),None)
            if p is None: power=P_OFF
            else:
                prev=self.last_measurement
                pair_ok=(reading is not None and prev is not None and
                         prev['pulse']==reading['pulse']==p.number and
                         abs(prev['time']-begin)<EPS and begin>=p.start+SETTLE-EPS and
                         end<=p.command_off+EPS)
                # Pmax covers every edge/settling interval lacking two settled endpoints.
                power=(prev['P']+reading['P'])/2 if pair_ok else P_MAX
            pieces.append((right-left,power))
        return pieces

    def update(self,reading):
        if self.time<=self.state_time+EPS: return
        for duration,power in self.model_segments(self.state_time,self.time,reading):
            remaining=duration
            hmax=.1*min(C_MIN/G,1/(BETA+GAMMA))
            while remaining>EPS:
                h=min(remaining,hmax); T,S=self.estimate
                self.estimate=np.array([T+h*(power-G*(T-S))/capacity(T),
                                        S+h*(BETA*(T-S)-GAMMA*(S-A))])
                remaining-=h
                if not GRID[0]-EPS<=self.estimate[0]<=GRID[-1]+EPS:
                    self.fault='calibration range'; self.stop('calibration range'); break
        self.state_time=self.time; self.last_pred_T=float(self.estimate[0])
        if not self.command_on: self.last_measurement=None; return
        if reading is not None:
            predicted=self.estimate[0]; window=np.abs(GRID-predicted)<=self.case.width
            temperatures=GRID[window]; values=Q_GRID[window]
            passes=np.abs(reading['y']-values)<=E_R+L
            starts=passes & ~np.r_[False,passes[:-1]]
            runs=int(np.count_nonzero(starts))
            if runs!=1:
                self.fault='branch ambiguity' if runs>1 else 'resistance mismatch'
                self.ambiguity_snapshot={'time':self.time,'predicted':float(predicted),
                    'truth':float(self.truth[0]),'y':float(reading['y']),
                    'width':self.case.width,'runs':runs,
                    'passing_temperatures':temperatures[passes].tolist()}
                self.stop(self.fault); self.last_measurement=None; return
            candidates=temperatures[passes]
            costs=((candidates-predicted)/self.case.width)**2+((reading['y']-np.interp(candidates,Q_T,Q_R))/E_R)**2
            best=int(np.argmin(costs)); chosen=float(candidates[best])
            if abs(reading['y']-q(predicted))<=E_R+L:
                continuous_cost=((reading['y']-q(predicted))/E_R)**2
                if continuous_cost<=costs[best]: chosen=float(predicted)
            self.estimate[0]=chosen; self.last_valid=self.time
            self.last_measurement=reading
        else: self.last_measurement=None
        self.set_deadline()

    def set_deadline(self):
        if not self.command_on: return
        limits={'temperature':self.state_time+(self.case.ceiling-MARGIN-max(self.estimate))*C_MIN/P_MAX-OFF_DELAY,
                'maximum duration':self.active.start+self.active.requested,
                'data expiry':self.last_valid+DATA_AGE-OFF_DELAY}
        self.deadline_reason=min(limits,key=limits.get); self.deadline=limits[self.deadline_reason]
        if self.deadline<=self.time+EPS: self.stop(self.deadline_reason)

    def start(self,p):
        self.update(None)  # Carry both OFF states to the requested start.
        if self.fault:
            p.reason='cancelled after '+self.fault; self.next_pulse+=1; return
        self.active=p; p.start_T=float(self.truth[0]); p.start_S=float(self.truth[1])
        p.peak_T=p.start_T; self.last_valid=self.time
        self.command_on=True
        self.set_deadline()  # Model the atomic deadline check, arm, and gate enable.
        if self.command_on: self.actual_on=True
        self.next_pulse+=1; self.record(None,'pulse start')

    def stop(self,reason):
        if not self.command_on: return
        self.command_on=False; self.deadline=math.inf
        self.active.command_off=self.time
        self.active.physical_off=self.time+OFF_DELAY
        self.active.reason=reason; self.active.stop_estimate=float(self.estimate[0])
        self.pending_off=self.active.physical_off

    def record(self,reading,event):
        r=reading or {}
        self.rows.append({'time_s':self.time,'T_true_C':float(self.truth[0]),'S_true_C':float(self.truth[1]),
            'T_est_C':float(self.estimate[0]),'S_est_C':float(self.estimate[1]),
            'T_prediction_C':self.last_pred_T,'state_time_s':self.state_time,
            'P_true_W':self.physical_power(self.truth[0]),'P_measured_W':r.get('P',math.nan),
            'V_measured_V':r.get('V',math.nan),'I_measured_A':r.get('I',math.nan),
            'q_true':q(self.truth[0]) if self.actual_on else math.nan,
            'q_measured':r.get('y',math.nan),'q_estimate':q(self.estimate[0]) if self.actual_on else math.nan,
            'command_on':int(self.command_on),'current_on':int(self.actual_on),
            'pulse':self.active.number if self.active else 0,'event':event,
            'fault':self.fault})

    def run(self):
        while self.time<self.end_time-EPS:
            start=self.pulses[self.next_pulse].start if self.next_pulse<len(self.pulses) else math.inf
            t=min(self.next_sample,start,self.deadline,self.pending_off,self.end_time)
            self.advance_truth(t)
            if abs(t-self.pending_off)<EPS:
                self.actual_on=False; self.pending_off=math.inf; self.record(None,'current off')
                if self.active.number==4 and not self.restart_added:
                    self.pulses.append(Pulse(5,t+.300,.050)); self.restart_added=True
            if self.command_on and self.deadline<=t+EPS:
                self.stop(self.deadline_reason); self.record(None,'timer off')
            if abs(t-start)<EPS: self.start(self.pulses[self.next_pulse])
            if abs(t-self.next_sample)<EPS:
                r=self.reading(); self.update(r); self.record(r,'sample')
                self.next_sample+=SAMPLE_DT
        return self


def save_csv(path,rows):
    with path.open('w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)

def arrays(sim): return {k:np.array([r[k] for r in sim.rows]) for k in sim.rows[0] if isinstance(sim.rows[0][k],(int,float))}

def style():
    plt.rcParams.update({'font.family':'DejaVu Sans','font.size':10,'axes.titlesize':12,'axes.labelsize':10,
        'legend.fontsize':9,'figure.facecolor':'white','axes.facecolor':'white','savefig.facecolor':'white',
        'axes.spines.top':False,'axes.spines.right':False,'axes.grid':True,'grid.color':'#dfe5e9',
        'grid.linewidth':.65,'axes.axisbelow':True,'svg.fonttype':'none','pdf.fonttype':42})

def finish(fig,name):
    fig.savefig(ROOT/'images'/f'{name}.png',dpi=220,bbox_inches='tight')
    fig.savefig(ROOT/'images'/f'{name}.svg',bbox_inches='tight');plt.close(fig)

BLUE,ORANGE,GREEN,GRAY='#17689a','#c35b14','#247a58','#657783'

def plot_train(sims):
    fig,axs=plt.subplots(3,2,figsize=(12,8),sharex='col',gridspec_kw={'height_ratios':[1.7,1,1]},layout='constrained')
    for col,sim in enumerate(sims):
        a=arrays(sim);t=a['time_s']; ax=axs[0,col]
        ax.plot(t,a['T_true_C'],c=BLUE,label='Simulated metal temperature',lw=1.6)
        ax.plot(t,a['T_est_C'],c=ORANGE,label='Controller estimate',lw=1.2,ls='--')
        ax.plot(t,a['S_true_C'],c=GREEN,label='Simulated surroundings',lw=1.2)
        ax.axhline(sim.case.ceiling,c='#8f3131',ls=':',lw=1,label='Requested ceiling')
        ax.set(title=sim.case.title,ylabel='Temperature (°C)',ylim=(10,485))
        axs[1,col].step(t,a['P_true_W'],where='post',c=BLUE,lw=1.2,label='Delivered power')
        axs[1,col].set(ylabel='Heater power (W)',ylim=(-.5,11.5))
        valid=np.isfinite(a['q_measured'])
        axs[2,col].plot(t,a['q_true'],c=BLUE,lw=1,label='Simulated normalized resistance')
        axs[2,col].scatter(t[valid][::4],a['q_measured'][valid][::4],s=3,c=ORANGE,alpha=.55,label='Synthetic V/I reading')
        axs[2,col].set(xlabel='Time (s)',ylabel=r'Normalized resistance $R/R_0$',ylim=(.995,1.060),xlim=(0,1.12))
        for p in sim.pulses:
            for row in range(3): axs[row,col].axvspan(p.start,p.start+p.requested,color='#cbd4db',alpha=.20,lw=0)
            axs[1,col].text(p.start+.002,10.8,str(p.number),fontsize=9,color=GRAY)
    handles,labels=axs[0,0].get_legend_handles_labels()
    fig.legend(handles,labels,loc='upper center',bbox_to_anchor=(.5,1.055),ncol=4,frameon=False)
    axs[2,0].legend(loc='lower right',frameon=True,framealpha=.94)
    fig.suptitle('Finite pulse sequence · grey bands show requested durations',fontsize=15,y=1.10)
    finish(fig,'pulse-trains')


def plot_closeup(sim):
    p=sim.pulses[1];a=arrays(sim);x=(a['time_s']-p.start)*1000
    keep=(x>=-.5)&(x<=(p.physical_off-p.start)*1000+4)
    fig,axs=plt.subplots(3,1,figsize=(9,7.3),sharex=True,layout='constrained')
    axs[0].plot(x[keep],a['T_true_C'][keep],c=BLUE,lw=1.7,label='Simulated metal temperature')
    axs[0].plot(x[keep],a['T_est_C'][keep],c=ORANGE,ls='--',lw=1.3,label='Controller estimate')
    axs[0].axhline(sim.case.ceiling-MARGIN,color=GRAY,ls=':',lw=1,label=r'Ceiling minus assumed margin: 435 °C')
    axs[0].axhline(sim.case.ceiling,c='#8f3131',ls=':',lw=1,label='Ceiling: 450 °C')
    axs[0].set(ylabel='Temperature (°C)');axs[0].legend(loc='lower right')
    axs[1].step(x[keep],a['P_true_W'][keep],where='post',c=BLUE,lw=1.4,label='Delivered power')
    ok=keep&np.isfinite(a['P_measured_W'])
    axs[1].scatter(x[ok][::2],a['P_measured_W'][ok][::2],s=7,c=ORANGE,alpha=.6,label='Measured V × I')
    axs[1].set(ylabel='Heater power (W)',ylim=(-.5,11));axs[1].legend(loc='lower left')
    axs[2].plot(x[keep],a['q_true'][keep],c=BLUE,lw=1.5,label='Simulated normalized resistance')
    axs[2].scatter(x[ok],a['q_measured'][ok],s=6,c=ORANGE,alpha=.6,label='Synthetic reading')
    axs[2].set(xlabel='Time after pulse 2 starts (ms)',ylabel=r'$R/R_0$');axs[2].legend(loc='lower right')
    for ax in axs:
        ax.axvline((p.command_off-p.start)*1000,c=GRAY,lw=.8,ls='--')
        ax.axvline((p.physical_off-p.start)*1000,c='#8f3131',lw=.8,ls=':')
        ax.set_xlim(-.5,(p.physical_off-p.start)*1000+4)
    fig.suptitle('Model mismatch · pulse 2 in detail\nDashed line: OFF command; dotted line: current ceases 50 µs later',fontsize=13)
    finish(fig,'pulse-detail')


def plot_ambiguity(sim):
    snap=sim.ambiguity_snapshot;a=arrays(sim)
    fig,axs=plt.subplots(1,2,figsize=(12,4.6),layout='constrained')
    axs[0].plot((a['time_s']-.05)*1000,a['T_true_C'],c=BLUE,label='Simulated metal temperature',lw=1.6)
    axs[0].plot((a['time_s']-.05)*1000,a['T_est_C'],c=ORANGE,ls='--',label='Controller estimate',lw=1.3)
    axs[0].axvline((snap['time']-.05)*1000,c='#8f3131',ls=':',label='Ambiguity → OFF')
    axs[0].set(xlabel='Time after pulse starts (ms)',ylabel='Temperature (°C)',xlim=(0,100),title='A 100 ms request ends early')
    axs[0].legend(loc='lower right')
    U=np.linspace(300,800,1001);axs[1].plot(U,np.interp(U,Q_T,Q_R),c=BLUE,lw=1.8,label='Manufacturer table interpolation')
    axs[1].axvspan(snap['predicted']-snap['width'],snap['predicted']+snap['width'],color=GRAY,alpha=.12,label='Prediction ± 150 K search')
    axs[1].axhspan(snap['y']-E_R-L,snap['y']+E_R+L,color=ORANGE,alpha=.2,label='Reading compatibility band')
    passed=np.array(snap['passing_temperatures'])
    axs[1].scatter(passed,np.interp(passed,Q_T,Q_R),s=11,c=GREEN,zorder=4,label='Two separated passing groups')
    axs[1].axvline(snap['predicted'],c=GRAY,lw=1,ls='--')
    axs[1].set(xlabel='Candidate temperature (°C)',ylabel=r'Normalized resistance $q(T)$',xlim=(350,720),ylim=(1.035,1.071),title='Resistance supports two local branches')
    axs[1].legend(loc='lower right',fontsize=8)
    fig.suptitle('Deliberately wide search · branch-ambiguity stop',fontsize=14)
    finish(fig,'branch-ambiguity')


def main():
    (ROOT/'data').mkdir(exist_ok=True);(ROOT/'images').mkdir(exist_ok=True)
    cases=[Case('reference','A · Reference thermal model'),
           Case('mismatch','B · Modest thermal mismatch',mass_scale=.92,G_scale=.90,beta_scale=1.10,gamma_scale=.90),
           Case('ambiguity','C · Branch ambiguity',width=150,ceiling=750,ambiguity=True)]
    sims=[Simulation(c).run() for c in cases]
    summaries=[]
    for sim in sims:
        save_csv(ROOT/'data'/f'{sim.case.key}-trace.csv',sim.rows)
        pr=[]
        for p in sim.pulses:
            d=asdict(p);d['command_duration_ms']=1000*(p.command_off-p.start);d['current_duration_ms']=1000*(p.physical_off-p.start)
            pr.append(d)
        save_csv(ROOT/'data'/f'{sim.case.key}-pulses.csv',pr)
        a=arrays(sim);use=np.isfinite(a['q_measured'])
        err=a['T_true_C'][use]-a['T_est_C'][use]
        summary={'case':asdict(sim.case),'maximum_true_temperature_C':float(np.max(a['T_true_C'])),
            'largest_underestimate_at_readings_K':float(max(0,np.max(err))) if len(err) else None,
            'reading_temperature_RMSE_K':float(np.sqrt(np.mean(err**2))) if len(err) else None,
            'fault':sim.fault,'pulses':pr,'ambiguity_snapshot':sim.ambiguity_snapshot}
        summaries.append(summary)
    config={'geometry_m':{'length':.010,'width':.001,'thickness':.000015},'mass_kg':MASS,'R0_ohm':R0,
        'ambient_C':A,'voltage_V':V_ON,'voltage_bound_V':V_MAX,'power_bound_W':P_MAX,'residual_power_W':P_OFF,
        'nominal_G_W_per_K':G,'nominal_beta_per_s':BETA,'nominal_gamma_per_s':GAMMA,
        'Cmin_J_per_K':C_MIN,'q_temperature_C':Q_T.tolist(),'q_values':Q_R.tolist(),
        'cp_temperature_C':CP_T.tolist(),'cp_J_per_kgK':CP.tolist(),
        'measurement_interval_s':SAMPLE_DT,'plant_RK4_max_step_s':TRUE_DT,'settling_s':SETTLE,
        'physical_off_delay_s':OFF_DELAY,'data_expiry_s':DATA_AGE,'resistance_allowance':E_R,
        'temperature_margin_K':MARGIN,'relative_voltage_bias':V_BIAS,'relative_current_bias':I_BIAS,
        'independent_relative_noise_SD':NOISE_SD,'seed':20261023,'cases':[asdict(c) for c in cases],
        'controller_source_sha256':CONTROLLER_SHA256}
    (ROOT/'constants.json').write_text(json.dumps(config,indent=2))
    (ROOT/'results.json').write_text(json.dumps(summaries,indent=2))
    style();plot_train(sims[:2]);plot_closeup(sims[1]);plot_ambiguity(sims[2])
    print(json.dumps([{k:v for k,v in s.items() if k not in ('pulses','ambiguity_snapshot')} for s in summaries],indent=2))
    for sim in sims:
        print(sim.case.key,[(p.number,round(1000*(p.command_off-p.start),3),round(p.peak_T,2),p.reason) for p in sim.pulses])

if __name__=='__main__': main()
